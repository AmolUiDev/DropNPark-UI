import React from 'react';

const Reports: React.FC = () => {
  return (
    <div>
      <h2>Reports</h2>
      <p>Generate and view various reports.</p>
    </div>
  );
};

export default Reports;
