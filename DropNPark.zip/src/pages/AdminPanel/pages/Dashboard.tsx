import React from 'react';

const Dashboard: React.FC = () => {
  return (
    <div>
      <h2>Dashboard</h2>
      <p>Welcome to the Admin Panel!</p>
    </div>
  );
};

export default Dashboard;
