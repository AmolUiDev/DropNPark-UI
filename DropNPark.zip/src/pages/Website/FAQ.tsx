import React from 'react';

const FAQ: React.FC = () => (
  <div className="container mt-4">
    <h2>FAQ</h2><p>Frequently asked questions.</p>
  </div>
);

export default FAQ;