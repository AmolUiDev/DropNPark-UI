import React from 'react';

const Location: React.FC = () => (
  <div className="container mt-4">
    <h2>Locations</h2><p>Find parking near you.</p>
  </div>
);

export default Location;