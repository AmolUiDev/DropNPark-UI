import React from 'react';
import { Button, Container, Row, Col } from "react-bootstrap";
import { Link } from 'react-router-dom';
import FAQ from '../../components/faq'
import Location from '../../img/location.svg';
import call from '../../img/call.svg';
import time from '../../img/time.svg';
import email from '../../img/envelope.svg';
import service1 from '../../img/srvc1.svg';
import service2 from '../../img/srvc2.svg';
import service3 from '../../img/srvc3.svg';
import service4 from '../../img/srvc4.svg';
import service5 from '../../img/srvc5.svg';
import service6 from '../../img/srvc6.svg';


const services = [
  {
    img: service1,
    title: "Luggage Assistance",
    description:
      "Help with loading and unloading luggage, including fragile or heavy items.",
  },
  {
    img: service2,
    title: "Car Wash & Detailing",
    description:
      "Exterior wash or full detailing while you’re away. Quick interior cleaning available.",
  },
  {
    img: service3,
    title: "Fuel Top-Up",
    description:
      "Fill up the tank before returning your car. Options for full or minimum fuel levels.",
  },
  {
    img: service4,
    title: "EV Charging",
    description:
      "Electric vehicle charging available for EVs while parked at our facility.",
  },
  {
    img: service5,
    title: "Car Maintenance Checks",
    description:
      "Basic checks like tire pressure, oil level, and windshield washer fluid.",
  },
  {
    img: service6,
    title: "Premium Membership",
    description:
      "Frequent traveler perks with discounted rates, priority valet, and free add-ons.",
  },
];


const Home: React.FC = () => {
  return (
  <div className="home-page">
    <section className="services-section section-padding pb-0">
      <Container>
        <Row>
          <Col className="text-center">
            <div className='heading-wrapper'>
              <h2>Additional Services</h2>
            </div>
          </Col>
        </Row>
        <Row className="desktop-view">
          {services.map((service, index) => (
            <Col md={6} lg={4} key={index} className="mb-4">
              <div className="service-card">
                <div className='service-card-info'>
                <div className="icon">
                  <img src={service.img} alt={service.title} />
                </div>
                <div className="content">
                  <h5>{service.title}</h5>
                  <p>{service.description}</p>
                </div>
                </div>
                <Button className="learn-more-btn">LEARN MORE</Button>
              </div>
            </Col>
          ))}
        </Row>

        <div className="mobile-slider">
          {services.map((service, index) => (
            <div className="service-card" key={index}>
              <div className='service-card-info'>
                <div className="icon">
                  <img src={service.img} alt={service.title} />
                </div>
              <div className="content">
                <h5>{service.title}</h5>
                <p>{service.description}</p>
              </div>
              </div>
              <Button className="learn-more-btn">LEARN MORE</Button>
            </div>
          ))}
        </div>
      </Container>
    </section>
    <section className='faq-section section-padding'>
      <Container>
        <Row>
          <Col className="text-center">
            <div className='heading-wrapper'>
              <h2>Frequently Asked Questions</h2>
              <p>Everything you need to know about DropNPark</p>
            </div>
          </Col>
        </Row>
        <Row>
          <Col md={8} className='mx-auto text-center'>
          <FAQ/>
          <Button as={Link} to="/" variant="outline-primary" className="main-button section-button">
                            View All FAQ’s
                </Button>
          </Col>
        </Row>
      </Container>
    </section>
    <section className='cta-section'>
      <Container>
        <Row>
          <Col className="text-center">
            <div className='heading-wrapper'>
              <h2>Ready for Stress-Free Travel?</h2>
              <Button as={Link} to="/" variant="outline-primary" className="main-button section-button">
                            Book Your Spot Now
                </Button>
            </div>
          </Col>
        </Row>
      </Container>
    </section>
    <section className='section-padding contact-section'>
      <Container>
        <Row>
          <Col className="text-center">
            <div className='heading-wrapper'>
              <h2>Find Us</h2>
              <p>Conveniently located at Toronto Pearson International Airport</p>
            </div>
          </Col>
        </Row>
        <Row className="justify-content-center">
          <Col md={7} className="">
            <div className='map-box h-100'>
              <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d184552.30943582457!2d-79.37805805!3d43.7182412!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89d4cb90d7c63ba5%3A0x323555502ab4c477!2sToronto%2C%20ON%2C%20Canada!5e0!3m2!1sen!2sin!4v1761454435339!5m2!1sen!2sin" width="100%" height="100%"  loading="lazy" referrerPolicy="no-referrer-when-downgrade"></iframe>
            </div>
          </Col>
          <Col md={5} className="">
            <div className='Contact-details-wrapper'>
              <div className='contact-box'>
                <span>
                  <img src={Location} alt="Location Icon" />
                </span>
                <div className='contact-info'>
                  <h4>Service Location</h4>
                  <p>Toronto Pearson International Airport 6301 Silver Dart Drive Mississauga, ON L5P 1B2, Canada</p>
                </div>
              </div>

              <div className='contact-box'>
                <span>
                  <img src={call} alt="call Icon" />
                </span>
                <div className='contact-info'>
                  <h4>Contact Details</h4>
                  <p>24/7 Customer Service</p>
                  <div className='phone-numbers'>
                    <a href="tel:+15551234567">
                      <span><img src={call} alt="call Icon" /></span>(555) 123-4567</a>
                    <a href="mailto:info@dropnpark.com">
                      <span><img src={email} alt="email Icon" /></span>info@dropnpark.com</a>
                  </div>
                </div>
              </div>

              <div className='contact-box'>
                <span>
                  <img src={time} alt="time Icon" />
                </span>
                <div className='contact-info'>
                  <h4>Operating Hours</h4>
                  <p>Open 24 hours a day<br></br>7 days a week<br></br>365 days a year</p>
                </div>
              </div>
            </div>
          </Col>
        </Row>
      </Container>
    </section>
  </div>
);
};
export default Home;