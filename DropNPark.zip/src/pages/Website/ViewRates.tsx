import React from 'react';

const ViewRates: React.FC = () => (
  <div className="container mt-4">
    <h2>View Rates</h2><p>Parking rates.</p>
  </div>
);

export default ViewRates;