import React, { useState } from "react";
import { Form, Button, Container, Row, Col } from "react-bootstrap";
import { Link, useNavigate } from 'react-router-dom';


const Registration: React.FC = () => {
 
  return (
    <div className="registration">
      {/* Inner banner */}
      <section className="inner-banner registration-banner">
        <Container>
          <Row className="align-items-center text-center">
            <Col>
              <h1 className="page-title">Welcome to the New <br></br><span>DropNPark</span> Rewards</h1>
            </Col>
          </Row>
        </Container>
      </section>


      <Container>
        <Row>
            <Col md={12} className="mx-auto">
                <span className="mandatory-warn">
                    * Mandatory fields
                </span>
                <div className="registration-form">
                    <Form>
                        <Form.Group className="custome-form-group">
                            <Form.Label>Airport Name *</Form.Label>
                            <Form.Control
                                type="text"
                                name="airportName"
                                placeholder="Enter Airport name & terminal"
                                required
                            />
                        </Form.Group>

                        <Form.Group className="custome-form-group">
                            <Form.Label>Drop Off Date and Time *</Form.Label>
                            <Form.Control
                            type="datetime-local"
                            name="dropOff"
                            required
                            />
                        </Form.Group>

                        <Form.Group className="custome-form-group">
                            <Form.Label>Pick Up Date and Time *</Form.Label>
                            <Form.Control
                            type="datetime-local"
                            name="pickUp"
                            required
                            />
                        </Form.Group>

                         <Form.Group className="custome-form-group">
                            <Form.Label>Service</Form.Label>
                            <Form.Select
                                name="service"
                            >
                                <option value="">Select Service</option>
                                <option value="valet">Valet Parking</option>
                                <option value="premium">Premium Parking</option>
                                <option value="longterm">Long Term Parking</option>
                            </Form.Select>
                        </Form.Group>

                        <h5 className="section-title">Your Information</h5>
                        <Form.Group className="custome-form-group">
                            <Form.Label>First Name *</Form.Label>
                            <Form.Control
                            type="text"
                            name="firstName"
                            placeholder="Enter your first name"
                            required
                            />
                        </Form.Group>

                        <Form.Group className="custome-form-group">
                            <Form.Label>Last Name *</Form.Label>
                            <Form.Control
                            type="text"
                            name="lastName"
                            placeholder="Enter your last name"
                            required
                            />
                        </Form.Group>

                        <Form.Group className="custome-form-group">
                            <Form.Label>Postal Code *</Form.Label>
                            <Form.Control
                            type="text"
                            name="postalCode"
                            placeholder="Enter your postal code"
                            required
                            />
                        </Form.Group>

                        <h5 className="section-title">Sign In Information</h5>

                        <Form.Group className="custome-form-group">
                            <Form.Label>Email Address *</Form.Label>
                            <Form.Control
                            type="email"
                            name="email"
                            placeholder="Enter your email"
                            required
                            />
                        </Form.Group>

                        <Form.Group className="custome-form-group">
                            <Form.Label>Confirm Email Address *</Form.Label>
                            <Form.Control
                            type="email"
                            name="email"
                            placeholder="Confirm your email"
                            required
                            />
                        </Form.Group>

                        <Form.Group className="custome-form-group">
                            <Form.Label>Password *</Form.Label>
                            <Form.Control
                            type="password"
                            name="password"
                            placeholder="Enter your password"
                            required
                            />
                        </Form.Group>

                        <Form.Group className="custome-form-group">
                            <Form.Label>Confirm Password *</Form.Label>
                            <Form.Control
                            type="password"
                            name="password"
                            placeholder="Confirm password"
                            required
                            />
                        </Form.Group>

                        <Form.Group className="custome-form-group">
                            <Form.Label>Mobile Number *</Form.Label>
                            <Form.Control
                            type="phone"
                            name="mobile"
                            placeholder="Enter your mobile number"
                            required
                            />
                        </Form.Group>

                        <h5 className="section-title">Vehicle Information</h5>


                        <Form.Group className="custome-form-group">
                            <Form.Label>Make</Form.Label>
                            <Form.Select
                                name="make"
                            >
                                <option value="">Make</option>
                                <option value="valet">Valet Parking</option>
                                <option value="premium">Premium Parking</option>
                                <option value="longterm">Long Term Parking</option>
                            </Form.Select>
                        </Form.Group>

                        <Form.Group className="custome-form-group">
                            <Form.Label>Type</Form.Label>
                            <Form.Select
                                name="type"
                            >
                                <option value="">Type</option>
                                <option value="valet">Valet Parking</option>
                                <option value="premium">Premium Parking</option>
                                <option value="longterm">Long Term Parking</option>
                            </Form.Select>
                        </Form.Group>

                        <Form.Group className="custome-form-group">
                            <Form.Label>Color</Form.Label>
                            <Form.Select
                                name="color"
                            >
                                <option value="">Color</option>
                                <option value="valet">Valet Parking</option>
                                <option value="premium">Premium Parking</option>
                                <option value="longterm">Long Term Parking</option>
                            </Form.Select>
                        </Form.Group>

                       <Form.Group className="custome-form-group">
                            <Form.Label>License Plate</Form.Label>
                            <Form.Control
                            type="text"
                            name="licensePlate"
                            placeholder="License Plate"
                            required
                            />
                        </Form.Group>

                        <Form.Group className="custome-form-group">
                            <Form.Label>Province / State</Form.Label>
                            <Form.Select
                                name="provincestate"
                            >
                                <option value="">Province / State</option>
                                <option value="valet">Valet Parking</option>
                                <option value="premium">Premium Parking</option>
                                <option value="longterm">Long Term Parking</option>
                            </Form.Select>
                        </Form.Group>

                        <Form.Group className="custome-form-group">
                            <Form.Label>Is this an electric vehicle?</Form.Label>
                            <Form.Select
                                name="elevehicle"
                            >
                                <option value="">Yes</option>
                                <option value="valet">No</option>
                            </Form.Select>
                        </Form.Group>

                        <Form.Group className="custome-form-group">
                            <Form.Label>Coupon/Redeem Code</Form.Label>
                            <Form.Control
                            type="text"
                            name="coupon"
                            placeholder="Select Coupon or Enter Redeem Code "
                            required
                            />
                        </Form.Group>

                        <div className="d-flex registration-btns">
                            <Button variant="primary" type="submit" className="me-3 primary-btn">
                                ADD VEHICLE
                            </Button>
                            <Link to="/login" className="btn btn-secondary secondary-btn">
                                REMOVE
                            </Link>
                        </div>

                    </Form>
                    <hr></hr>
                        <h5 className="section-title">Notification Settings</h5>
                        <div className="notificatin-text">
                        <p>Subscribe to the following communication options by selecting
                            the appropriate checkbox</p>
                            <h6>I would like to receive communication relating to my reservation:</h6>
                            <span>(Must select at least one option)</span>
                        <div className="d-flex checkbox-group">
                            <Form.Check
                                type="checkbox"
                                id="email"
                                label="Via Email"
                                />

                                <Form.Check
                                    type="checkbox"
                                    id="sms"
                                    label="Via SMS"    
                                />
                        </div>
                        <div className="d-flex registration-btns">
                            <Button variant="primary" type="submit" className=" primary-btn">
                                REGISTER
                            </Button>
                        </div>
                        <p className="mb-32">By registering, you agree to DropNPark<br></br>
<Link to=''>Terms & Conditions</Link> and <Link to=''>Privacy Policy</Link>.</p>
<p>Already have an account? <Link to=''>Sign In</Link></p>
                        </div>
                </div>
            </Col>
        </Row>
      </Container>
    </div>
  );
  
};

export default Registration;
